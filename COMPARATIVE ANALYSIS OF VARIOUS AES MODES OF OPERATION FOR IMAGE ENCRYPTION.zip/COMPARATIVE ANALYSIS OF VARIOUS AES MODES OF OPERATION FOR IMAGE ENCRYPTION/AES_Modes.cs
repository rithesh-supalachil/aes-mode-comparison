﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class AES_Modes : Form
    {
        public AES_Modes()
        {
            InitializeComponent();
        }

        private void AES_Modes_Load(object sender, EventArgs e)
        {

        }

        string filepath = null, mode;

        private void btnProceed_Click(object sender, EventArgs e)
        {
            var script = @"C:\Files\VS_Projects\AES_Modes\FinalProject\PyFile\aes_modes.py";

            if (rbECB.Checked == true)
                mode = "ECB";
            else if (rbCBC.Checked == true)
                mode = "CBC";
            else if (rbCCM.Checked == true)
                mode = "CCM";
            else if (rbCFB.Checked == true)
                mode = "CFB";
            else if (rbCTR.Checked == true)
                mode = "CTR";
            else if (rbGCM.Checked == true)
                mode = "GCM";
            else if (rbOCB.Checked == true)
                mode = "OCB";
            else if (rbOFB.Checked == true)
                mode = "OFB";


            var timeoutSignal = new CancellationTokenSource(TimeSpan.FromMinutes(3));

            // 1) Create Process Info
            var psi = new ProcessStartInfo();
            psi.FileName = @"C:\Program Files (x86)\Microsoft Visual Studio\Shared\Python37_64\python.exe";

            // 2) Provide script and arguments

            psi.Arguments = $"\"{script}\" \"{filepath}\" \"{mode}\"";

            // 3) Process configuration
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;

            // 4) Execute process and get output
            var errors = "";
            var results = "";

            using (var process = Process.Start(psi))
            {
                errors = process.StandardError.ReadToEnd();
                results = process.StandardOutput.ReadToEnd();
            }

            if(filepath == null)
                MessageBox.Show("Select a File. \n" + results, "Results");
            else
                MessageBox.Show("Encryption and Decryption Successful. \n" + results, "Results");

        }


        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                InitialDirectory = @"C:\Files\Project",
                Title = "Select File",

                CheckFileExists = true,
                CheckPathExists = true,

                FilterIndex = 2,
                RestoreDirectory = true,

            };

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                lblFilePath.Text = openFileDialog1.FileName;
                filepath = lblFilePath.Text;

                try
                {
                    pbImg.Image = Image.FromFile(filepath);
                }

                catch (System.OutOfMemoryException)
                {
                    //
                }
                
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
