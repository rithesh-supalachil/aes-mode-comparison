import sys
sys.path.append(r'C:\Program Files\WindowsApps\PythonSoftwareFoundation.Python.3.10_3.10.2288.0_x64__qbz5n2kfra8p0\Lib')
import hashlib
import time
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
import tracemalloc

BLOCK_SIZE = 32

filepath = sys.argv[1]
aes_mode = sys.argv[2]
enc_pass = "password"
aes_enc_mode = AES.MODE_ECB




if aes_mode == "ECB":
    aes_enc_mode = AES.MODE_ECB
elif aes_mode == "CBC":
	aes_enc_mode = AES.MODE_CBC
	BLOCK_SIZE = 16
elif aes_mode == "CFB":
	aes_enc_mode = AES.MODE_CFB
elif aes_mode == "OFB":
	aes_enc_mode = AES.MODE_OFB
elif aes_mode == "CTR":
    aes_enc_mode = AES.MODE_CTR
elif aes_mode == "OCB":
    aes_enc_mode = AES.MODE_OCB
elif aes_mode == "CCM":
    aes_enc_mode = AES.MODE_CCM
elif aes_mode == "GCM":
	aes_enc_mode = AES.MODE_GCM


dec_file_path = r"C:\Files\VS_Projects\Project1\Output\aes_encrypted.enc"
op_file_path = r"C:\Files\VS_Projects\Project1\Output"


# ENCRPT 1

def enc_image_type1(input_data, key, iv, filepath, aes_enc_mode):

	#Memory Trace Begin
	tracemalloc.start()
	enc_start = time.time()

	enc_cipher = AES.new(key, aes_enc_mode, iv)
	enc_data = enc_cipher.encrypt(pad(input_data, BLOCK_SIZE))

	enc_end = time.time()
	curr_mem, peak_mem = tracemalloc.get_traced_memory()

	#Saving to Memory
	enc_file = open(filepath+"/aes_encrypted.enc", "wb")
	enc_file.write(enc_data)
	enc_file.close()


	#Calculations
	memory = peak_mem / (1024*1024)
	print("Peak Memory: ",memory, "Kilobytes")
	tracemalloc.stop()

	enc_time = enc_end - enc_start
	print("Encryption Time: ", str(enc_time), " seconds")


def enc_image_type2(input_data, key, iv, filepath, aes_enc_mode):

	#Memory Trace Begin
	tracemalloc.start()
	enc_start = time.time()

	enc_cipher = AES.new(key, aes_enc_mode)
	enc_data = enc_cipher.encrypt(pad(input_data, BLOCK_SIZE))

	enc_end = time.time()
	curr_mem, peak_mem = tracemalloc.get_traced_memory()

	#Saving to Memory
	enc_file = open(filepath+"/aes_encrypted.enc", "wb")
	enc_file.write(enc_data)
	enc_file.close()

	#Calculations
	memory = peak_mem / (1024*1024)
	print("Peak Memory: ",memory, "Kilobytes")
	tracemalloc.stop()

	enc_time = enc_end - enc_start
	print("Encryption Time: ", str(enc_time), " seconds")


def dec_image_type1(input_data,key,iv,filepath, aes_enc_mode):
	#Memory Trace Begin
	tracemalloc.start()
	dec_start = time.time()

	#DECRYPTION
	enc_decipher = AES.new(key, aes_enc_mode, iv)
	plain_data = enc_decipher.decrypt(input_data)

	dec_end = time.time()
	curr_mem, peak_mem = tracemalloc.get_traced_memory()	

	#Saving to Memory
	output_file = open(filepath+"/aes_decrypted.jpg", "wb")
	output_file.write(plain_data)
	output_file.close()

	#Calculations
	memory = peak_mem / (1024*1024)
	print("Peak Memory: ",memory, "Kilobytes")
	tracemalloc.stop()

	dec_time = dec_end - dec_start
	print("Decryption Time: ", str(dec_time), " seconds")


def dec_image_type2(input_data,key,iv,filepath, aes_enc_mode):

	#Memory Trace Begin
	tracemalloc.start()
	dec_start = time.time()

	#DECRYPTION
	enc_decipher = AES.new(key, aes_enc_mode)
	plain_data = enc_decipher.decrypt(input_data)

	dec_end = time.time()
	curr_mem, peak_mem = tracemalloc.get_traced_memory()	

	#Saving to Memory
	output_file = open(filepath+"/aes_decrypted.jpg", "wb")
	output_file.write(plain_data)
	output_file.close()

	#Calculations
	memory = peak_mem / (1024*1024)
	print("Peak Memory: ",memory, "Kilobytes")
	tracemalloc.stop()

	dec_time = dec_end - dec_start
	print("Decryption Time: ", str(dec_time), " seconds")






#GENERATE KEY & INITIALIZATION VECTOR
hash = hashlib.sha256(enc_pass.encode()) 
p = hash.digest()
key = p
iv = p.ljust(16)[:16]

input_file = open(filepath,'rb')
input_data = input_file.read()
input_file.close()


if aes_mode == "CBC" or aes_mode == "CFB" or aes_mode == "OFB" or aes_mode == "GCM":
	enc_image_type1(input_data, key, iv, op_file_path, aes_enc_mode)

elif aes_mode == "ECB" or aes_mode == "CTR" or aes_mode == "CCM" or aes_mode == "OCB":
	enc_image_type2(input_data, key, iv, op_file_path, aes_enc_mode)





#GENERATE KEY & INITIALIZATION VECTOR
hash = hashlib.sha256(enc_pass.encode()) 
p = hash.digest()
key = p
iv = p.ljust(16)[:16]

input_file = open(dec_file_path,'rb')
input_data = input_file.read()
input_file.close()


if aes_mode == "CBC" or aes_mode == "CFB" or aes_mode == "OFB" or aes_mode == "GCM":
	dec_image_type1(input_data, key, iv, op_file_path, aes_enc_mode)

elif aes_mode == "ECB" or aes_mode == "CTR" or aes_mode == "CCM" or aes_mode == "OCB":
	dec_image_type2(input_data, key, iv, op_file_path, aes_enc_mode)