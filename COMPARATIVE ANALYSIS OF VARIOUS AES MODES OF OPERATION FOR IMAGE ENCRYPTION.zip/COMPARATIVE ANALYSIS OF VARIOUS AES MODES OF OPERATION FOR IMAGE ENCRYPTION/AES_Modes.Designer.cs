﻿
namespace FinalProject
{
    partial class AES_Modes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.rbECB = new System.Windows.Forms.RadioButton();
            this.rbCBC = new System.Windows.Forms.RadioButton();
            this.rbCFB = new System.Windows.Forms.RadioButton();
            this.rbOFB = new System.Windows.Forms.RadioButton();
            this.rbCTR = new System.Windows.Forms.RadioButton();
            this.rbOCB = new System.Windows.Forms.RadioButton();
            this.rbCCM = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.lblFilePath = new System.Windows.Forms.Label();
            this.pbImg = new System.Windows.Forms.PictureBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.btnProceed = new System.Windows.Forms.Button();
            this.rbGCM = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.pbImg)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(23, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(666, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Comparative Analysis of Various AES Modes of Operation for Image Encryption";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // rbECB
            // 
            this.rbECB.AutoSize = true;
            this.rbECB.Location = new System.Drawing.Point(54, 98);
            this.rbECB.Name = "rbECB";
            this.rbECB.Size = new System.Drawing.Size(170, 19);
            this.rbECB.TabIndex = 1;
            this.rbECB.TabStop = true;
            this.rbECB.Text = "ECB - Electronic Code Book";
            this.rbECB.UseVisualStyleBackColor = true;
            // 
            // rbCBC
            // 
            this.rbCBC.AutoSize = true;
            this.rbCBC.Location = new System.Drawing.Point(54, 137);
            this.rbCBC.Name = "rbCBC";
            this.rbCBC.Size = new System.Drawing.Size(179, 19);
            this.rbCBC.TabIndex = 2;
            this.rbCBC.TabStop = true;
            this.rbCBC.Text = "CBC - Cipher-Block Chaining";
            this.rbCBC.UseVisualStyleBackColor = true;
            // 
            // rbCFB
            // 
            this.rbCFB.AutoSize = true;
            this.rbCFB.Location = new System.Drawing.Point(54, 176);
            this.rbCFB.Name = "rbCFB";
            this.rbCFB.Size = new System.Drawing.Size(145, 19);
            this.rbCFB.TabIndex = 3;
            this.rbCFB.TabStop = true;
            this.rbCFB.Text = "CFB - Cipher FeedBack";
            this.rbCFB.UseVisualStyleBackColor = true;
            // 
            // rbOFB
            // 
            this.rbOFB.AutoSize = true;
            this.rbOFB.Location = new System.Drawing.Point(54, 215);
            this.rbOFB.Name = "rbOFB";
            this.rbOFB.Size = new System.Drawing.Size(149, 19);
            this.rbOFB.TabIndex = 4;
            this.rbOFB.TabStop = true;
            this.rbOFB.Text = "OFB - Output FeedBack";
            this.rbOFB.UseVisualStyleBackColor = true;
            // 
            // rbCTR
            // 
            this.rbCTR.AutoSize = true;
            this.rbCTR.Location = new System.Drawing.Point(54, 254);
            this.rbCTR.Name = "rbCTR";
            this.rbCTR.Size = new System.Drawing.Size(135, 19);
            this.rbCTR.TabIndex = 5;
            this.rbCTR.TabStop = true;
            this.rbCTR.Text = "CTR - CounTer Mode";
            this.rbCTR.UseVisualStyleBackColor = true;
            // 
            // rbOCB
            // 
            this.rbOCB.AutoSize = true;
            this.rbOCB.Location = new System.Drawing.Point(54, 332);
            this.rbOCB.Name = "rbOCB";
            this.rbOCB.Size = new System.Drawing.Size(150, 19);
            this.rbOCB.TabIndex = 6;
            this.rbOCB.TabStop = true;
            this.rbOCB.Text = "OCB - Offset CodeBook";
            this.rbOCB.UseVisualStyleBackColor = true;
            // 
            // rbCCM
            // 
            this.rbCCM.AutoSize = true;
            this.rbCCM.Location = new System.Drawing.Point(54, 293);
            this.rbCCM.Name = "rbCCM";
            this.rbCCM.Size = new System.Drawing.Size(116, 19);
            this.rbCCM.TabIndex = 7;
            this.rbCCM.TabStop = true;
            this.rbCCM.Text = "CCM - CBC MAC";
            this.rbCCM.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(354, 132);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 15);
            this.label2.TabIndex = 8;
            this.label2.Text = "File Path:";
            // 
            // lblFilePath
            // 
            this.lblFilePath.AutoSize = true;
            this.lblFilePath.Location = new System.Drawing.Point(416, 132);
            this.lblFilePath.Name = "lblFilePath";
            this.lblFilePath.Size = new System.Drawing.Size(91, 15);
            this.lblFilePath.TabIndex = 9;
            this.lblFilePath.Text = "No File Selected";
            // 
            // pbImg
            // 
            this.pbImg.Location = new System.Drawing.Point(359, 163);
            this.pbImg.Name = "pbImg";
            this.pbImg.Size = new System.Drawing.Size(252, 182);
            this.pbImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbImg.TabIndex = 10;
            this.pbImg.TabStop = false;
            this.pbImg.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(354, 96);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnBrowse.TabIndex = 11;
            this.btnBrowse.Text = "Browse File";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // btnProceed
            // 
            this.btnProceed.Location = new System.Drawing.Point(458, 361);
            this.btnProceed.Name = "btnProceed";
            this.btnProceed.Size = new System.Drawing.Size(75, 23);
            this.btnProceed.TabIndex = 12;
            this.btnProceed.Text = "Proceed";
            this.btnProceed.UseVisualStyleBackColor = true;
            this.btnProceed.Click += new System.EventHandler(this.btnProceed_Click);
            // 
            // rbGCM
            // 
            this.rbGCM.AutoSize = true;
            this.rbGCM.Location = new System.Drawing.Point(54, 371);
            this.rbGCM.Name = "rbGCM";
            this.rbGCM.Size = new System.Drawing.Size(175, 19);
            this.rbGCM.TabIndex = 13;
            this.rbGCM.TabStop = true;
            this.rbGCM.Text = "GCM - Galois Counter Mode";
            this.rbGCM.UseVisualStyleBackColor = true;
            // 
            // AES_Modes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(716, 455);
            this.Controls.Add(this.rbGCM);
            this.Controls.Add(this.btnProceed);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.pbImg);
            this.Controls.Add(this.lblFilePath);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.rbCCM);
            this.Controls.Add(this.rbOCB);
            this.Controls.Add(this.rbCTR);
            this.Controls.Add(this.rbOFB);
            this.Controls.Add(this.rbCFB);
            this.Controls.Add(this.rbCBC);
            this.Controls.Add(this.rbECB);
            this.Controls.Add(this.label1);
            this.Name = "AES_Modes";
            this.Text = "AES_Modes";
            this.Load += new System.EventHandler(this.AES_Modes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbImg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rbECB;
        private System.Windows.Forms.RadioButton rbCBC;
        private System.Windows.Forms.RadioButton rbCFB;
        private System.Windows.Forms.RadioButton rbOFB;
        private System.Windows.Forms.RadioButton rbCTR;
        private System.Windows.Forms.RadioButton rbOCB;
        private System.Windows.Forms.RadioButton rbCCM;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblFilePath;
        private System.Windows.Forms.PictureBox pbImg;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Button btnProceed;
        private System.Windows.Forms.RadioButton rbGCM;
    }
}